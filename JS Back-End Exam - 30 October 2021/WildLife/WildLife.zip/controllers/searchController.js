// const { hasUser } = require("../middlewares/guard");

// // hasUser() guard
// homeController.get('/search', async (req,res) => {
//     console.log(req.query);

//     cryptos = await getAllBySearch(req.query.search, req.query.payment)

//     res.render('search', {
//         title: 'Search Page',
//         cryptos,
//         search: req.query.search,
//     })
// })

